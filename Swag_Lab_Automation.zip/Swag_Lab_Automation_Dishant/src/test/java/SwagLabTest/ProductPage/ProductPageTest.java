package SwagLabTest.ProductPage;

import Base.BaseTest;
import DataFactory.ProductPageData;
import DataObjects.ProductPage;
import PageObjects.LoginPO.LoginPO;
import PageObjects.ProductPO.ProductPO;
import Utilities.Constants;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import static Utilities.Constants.URL;

public class ProductPageTest extends BaseTest {

    /*Test 1: Verify that the user able to add the product in cart successfully*/
    @Test
    public void verifyThatUserIsAbleToAddProductOnCartSuccessfully() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button in product");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Verify That shopping cart icon as per item selection");
        Assert.assertTrue(product.isDisplayed(By.xpath("//span[text()='3']")), "Number is not Matched");
    }

    /*Test 2: Verify that the user is able to select the product by adding to cart on individual page*/
    @Test
    public void verifyThatUserIsAbleToAddToCartTheProductFromIndividualProductPage() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on Product Link");
        product.clickOnAddToCartFromIndividualProductLink(pro);

        Reporter.log("Step 5: Verify that product is added into cart");
        Assert.assertTrue(product.isDisplayed(By.xpath("//span[text()='1']")), "Number is not Matched");
    }

    /*Test 3: Verify that the user is successfully navigated to 'Your Cart' Page after Clicking 'cart' symbol*/
    @Test
    public void verifyThatAfterAddingProductInCartUserNavigatedToYourCartPage() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");
    }

    /*Test 4: Verify that user is able to sort the product from sort dropdown */
    @Test
    public void verifyThatUserIsSortTheProductFromDropdown() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Verify  that user is select dropdown and click on options in that");
        product.selectTheValueFromDropdown(pro);

        Reporter.log("Step 5: Verify that product page is displayed as per sorting dropdown value");  //important
        String expectedProductName = "Sauce Labs Onesie";
        String name = "//div[@class='inventory_item']//div[@class='inventory_item_description']//div[text()='Sauce Labs Onesie']";
        String actualProductName = selenium.getText(By.xpath(name));
        Assert.assertEquals(actualProductName, expectedProductName, "Name not matched");

        String price = "//div[@class='inventory_item']//div[@class='inventory_item_description']//div[@class='pricebar']//div[text()='7.99']";
        String actualPrice = selenium.getText(By.xpath(price));
        String expectedPrice = "$7.99";
        Assert.assertEquals(actualPrice, expectedPrice, "Price is not Matched");

    }

}
