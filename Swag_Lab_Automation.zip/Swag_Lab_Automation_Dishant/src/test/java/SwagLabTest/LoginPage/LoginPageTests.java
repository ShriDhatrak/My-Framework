package SwagLabTest.LoginPage;

import Base.BaseTest;
import DataObjects.Login;
import PageObjects.LoginPO.LoginPO;
import Utilities.Constants;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import DataFactory.loginData;

import static Utilities.Constants.URL;

public class LoginPageTests extends BaseTest {

    /*Test 1: Verify that the logo is displayed as per Requirement*/
    @Test(priority = 0)
    public void verifyThatTheLogoIsDisplayed() {
        LoginPO login = new LoginPO(driver);

        Reporter.log("Step 1: Navigate too URL");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2 :Verify the Logo");
        Assert.assertTrue(login.isLogoDisplayed(), "Logo not Displayed");

    }

    /*Test 2: Verify that User is login Successfully*/
    @Test(priority = 1)
    public void verifyThatUserLoginSuccessfully() throws InterruptedException {
        LoginPO login = new LoginPO(driver);


        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Steop 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

    }

    /*Test 3: Verify that after entering invalid data warning message is displayed*/
    @Test(priority = 2)
    public void verifyThatValidationMessageIsDisplayedOnEnterringInvalidCredentials() throws InterruptedException {

        LoginPO login = new LoginPO(driver);
        Login data = new loginData().getLoginData();

        Reporter.log("Step 1: Navigate to URL");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter Invalid Username and Password and Click On Login Button");
        login.loginWithInvalidCredentials(data);

        Reporter.log("Step 3: Verify that Validation Message is displayed");
        String expectedMessage = "Epic sadface: Username and password do not match any user in this service";
        Assert.assertEquals(login.getWarnMessage(), expectedMessage, "Validation message is not displayed");
    }

    /* Test 4:Verify that login with blank credentials warning message is displayed*/
    @Test(priority = 3)
    public void verifyThatValidationMessageIsDisplayedWhenLoginWithBlankCredentials() throws InterruptedException {
        LoginPO login = new LoginPO(driver);

        Reporter.log("Step 1; Navigate to URL");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Click on Login Button");
        login.clickOnLoginButton();

        Reporter.log("Step 3: Verify that validation message is displayed");
        String expectedMessage="Epic sadface: Username is required";
        Assert.assertEquals(login.getBlankWarnMessage(),expectedMessage,"Warning message is not displayed");
    }


}
