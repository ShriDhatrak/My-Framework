package SwagLabTest.OverviewPage;

import Base.BaseTest;
import DataFactory.CheckYourInformationData;
import DataFactory.ProductPageData;
import DataObjects.CheckYourInformation;
import DataObjects.ProductPage;
import PageObjects.CheckYourInformationPO.CheckYourInformationPO;
import PageObjects.LoginPO.LoginPO;
import PageObjects.OverViewPO.OverviewPagePO;
import PageObjects.ProductPO.ProductPO;
import PageObjects.YourCartPO.YourCartPO;
import Utilities.Constants;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import static Utilities.Constants.URL;

public class OverviewPageTest extends BaseTest {

    /* Test1: Verify that user is navigated to 'Complete' page after clicking on finish button */
    @Test
    public void verifyThatUserIsNavigatedToCompletePageAfterClickingOnFinish() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();
        CheckYourInformationPO check = new CheckYourInformationPO(driver);
        CheckYourInformation checkInfo = new CheckYourInformationData().getCheckYourInformationData();
        OverviewPagePO overview = new OverviewPagePO(driver);

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 7:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

        Reporter.log("Step 8:Verify that user enters data in your information fields");
        check.enterValidDataInYourInformationPage(checkInfo);

        Reporter.log("Step 9:Verify that user successfully navigated to overview page");
        String name = "//span[text()='Checkout: Overview']";
        String actualName = selenium.getText(By.xpath(name));
        String expectedName = "CHECKOUT: OVERVIEW";
        Assert.assertEquals(actualName, expectedName, "Text is Not Matched");

        Reporter.log("Step 10: click on 'Finish' Button");
        overview.clickOnFinishButton();

        Reporter.log("Step 11: Verify that user is successfully navigated to 'complete' page");
        String titleName = "//span[text()='Checkout: Complete!']";
        String actualTitleName = selenium.getText(By.xpath(titleName));
        String expectedTitleName = "CHECKOUT: COMPLETE!";
        Assert.assertEquals(actualTitleName, expectedTitleName, "Text is Not Matched");
    }

    /* Test2:Verify that user is navigated to 'Complete' page after clicking on finish button */
    @Test
    public void verifyThatUserIsSuccessfullyRevertBackToProductPageAfterClickingCancel() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();
        CheckYourInformationPO check = new CheckYourInformationPO(driver);
        CheckYourInformation checkInfo = new CheckYourInformationData().getCheckYourInformationData();
        OverviewPagePO overview = new OverviewPagePO(driver);

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 7:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

        Reporter.log("Step 8:Verify that user enters data in your information fields");
        check.enterValidDataInYourInformationPage(checkInfo);

        Reporter.log("Step 9:Verify that user successfully navigated to overview page");
        String name = "//span[text()='Checkout: Overview']";
        String actualName = selenium.getText(By.xpath(name));
        String expectedName = "CHECKOUT: OVERVIEW";
        Assert.assertEquals(actualName, expectedName, "Text is Not Matched");

        Reporter.log("Step 10: click on 'Cancel' Button");
        overview.clickOnCancelButton();

        Reporter.log("Step 11:Verify that user is navigated to product page after click9ing on 'cancel' button");
        String titleName = "//span[text()='Products']";
        String actualTitleName = selenium.getText(By.xpath(titleName));
        String expectedTitleName = "PRODUCTS";
        Assert.assertEquals(actualTitleName, expectedTitleName, "Text is Not Matched");

    }
}

