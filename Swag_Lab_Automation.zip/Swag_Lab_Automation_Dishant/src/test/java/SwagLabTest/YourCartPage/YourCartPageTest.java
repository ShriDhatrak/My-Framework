package SwagLabTest.YourCartPage;

import Base.BaseTest;
import DataFactory.ProductPageData;
import DataObjects.ProductPage;
import PageObjects.LoginPO.LoginPO;
import PageObjects.ProductPO.ProductPO;
import PageObjects.YourCartPO.YourCartPO;
import Utilities.Constants;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import static Utilities.Constants.URL;

public class YourCartPageTest extends BaseTest {

    /*Test 1: Verify that user is click on Checkout button and successfully navigated to next page*/
    @Test
    public void verifyThatUserSuccessfullyClickOnCheckoutButton() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 3: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 4: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 5: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 6:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

    }

    /*Test 2: Verify that user is removes the products from your cart page */
    @Test
    public void verifyThatUserRemovesTheProductFromYourCartPage() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 3: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 4: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 5: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 6:Verify that after clicking on remove button successfully product is removed from yor cart page");
        cart.clickOnRemoveButton();
        cart.clickOnRemoveButton();
        cart.clickOnRemoveButton();

        Reporter.log("Step 7: Verify that no product is present in your Cart Page");
        Assert.assertFalse(cart.isProductPresent(), "Product is Present");
    }

    /*Test 3: Verify that user is successfully navigated to product page after clicking on 'continue shopping' button'*/
    @Test
    public void verifyThatUserSuccessfullyRevertBackToProductPage() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);
        ProductPage pro = new ProductPageData().getProductPageData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 3: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 4: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 5: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 5: Click on 'continue shopping' button");
        cart.clickOnContinueShoppingButton();

        Reporter.log("Step 6: Verify that user is successfully revert back to product page");
        String name = "//span[text()='Products']";
        String actualName = selenium.getText(By.xpath(name));
        String expectedName = "PRODUCTS";
        Assert.assertEquals(actualName, expectedName, "Text is Not Matched");
    }

}
