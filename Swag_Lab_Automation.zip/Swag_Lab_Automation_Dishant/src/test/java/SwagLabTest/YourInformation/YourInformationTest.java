package SwagLabTest.YourInformation;

import Base.BaseTest;
import DataFactory.CheckYourInformationData;
import DataFactory.ProductPageData;
import DataObjects.CheckYourInformation;
import DataObjects.ProductPage;
import PageObjects.CheckYourInformationPO.CheckYourInformationPO;
import PageObjects.LoginPO.LoginPO;
import PageObjects.ProductPO.ProductPO;
import PageObjects.YourCartPO.YourCartPO;
import Utilities.Constants;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import static Utilities.Constants.URL;

public class YourInformationTest extends BaseTest {

    /*Test 1: Verify that user is successfully enters valid data  in your information page and successfully navigate to overview*/
    @Test
    public void verifyThatUserSuccessfullyEnterTheDataInYourInformationAndNavigateToOverviewPage() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);

        ProductPage pro = new ProductPageData().getProductPageData();
        CheckYourInformationPO check = new CheckYourInformationPO(driver);
        CheckYourInformation checkinfo = new CheckYourInformationData().getCheckYourInformationData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 7:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

        Reporter.log("Step 8:Verify that user enters data in your information fields");
        check.enterValidDataInYourInformationPage(checkinfo);

        Reporter.log("Step 9:Verify that user successfully navigated to overview page");
        String name = "//span[text()='Checkout: Overview']";
        String actualName = selenium.getText(By.xpath(name));
        String expectedName = "CHECKOUT: OVERVIEW";
        Assert.assertEquals(actualName, expectedName, "Text is Not Matched");

    }

    /*Test 2: Verify that user is successfully return back to your cart page after clicking on cancel button*/
    @Test
    public void verifyThatUserSuccessfullyRevertBackToYourCartAfterClickingOnCancel() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);

        ProductPage pro = new ProductPageData().getProductPageData();
        CheckYourInformationPO check = new CheckYourInformationPO(driver);
        CheckYourInformation checkinfo = new CheckYourInformationData().getCheckYourInformationData();

        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 7:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

        Reporter.log("Step 8:Click on Cancel Button");
        check.clickOnCancelButton();

        Reporter.log("Step 9: Verify that after clicking successfully revert back to Your Cart Page after clicking on 'cancel' button");
        String name = "//span[text()='Your Cart']";
        String actualName = selenium.getText(By.xpath(name));
        String expectedName = "YOUR CART";
        Assert.assertEquals(actualName, expectedName, "Text is Not Matched");
    }

    /*Test 3: Verify that user is successfully logout from your information page*/
    @Test
    public void verifyThatUserSuccessfullyNavigateToLoginPageAfterClickingOnLogout() throws InterruptedException {
        LoginPO login = new LoginPO(driver);
        ProductPO product = new ProductPO(driver);
        YourCartPO cart = new YourCartPO(driver);

        ProductPage pro = new ProductPageData().getProductPageData();
        CheckYourInformationPO check = new CheckYourInformationPO(driver);


        Reporter.log("Step 1: Navigate to URl");
        selenium.navigateToPage(URL);

        Reporter.log("Step 2: Enter  valid login credentials and click on the Login button");
        login.loginWithValidCredentials(Constants.UserName, Constants.Password);

        Reporter.log("Step 3: Verify that user successfully navigated to product page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        System.out.println(driver.getTitle());

        Reporter.log("Step 4: Click on 'Add to Cart' Button");
        product.clickOnAddToCartButton(pro);

        Reporter.log("Step 5: Click on 'cart' symbol");
        product.clickOnShoppingCartSymbol();

        Reporter.log("Step 6: Verify that user successfully navigated to 'Your cart' page");
        Assert.assertEquals(driver.getTitle(), "Swag Labs", "Title Text is not Matched");
        Assert.assertTrue(selenium.isElementPresent(By.xpath("//button[@id='checkout']")), "'Checkout' Button is not Present");

        Reporter.log("Step 7:Verify that after clicking successfully navigated to Checkout Your Information Page");
        cart.clickOnCheckoutButton();
        String continueButton = "//input[@id=\"continue\"]";
        Assert.assertTrue(selenium.isElementPresent(By.xpath(continueButton)), "'Continue' Button is not Present");

        Reporter.log("Step 8:Click on logoutLink");
        check.clickOnLogoutLink();

        Reporter.log("Step 9:Verify that after clicking logout link user navigate to login page");
        Assert.assertTrue(login.isLogoDisplayed(), "Logo not Displayed");
    }

}
