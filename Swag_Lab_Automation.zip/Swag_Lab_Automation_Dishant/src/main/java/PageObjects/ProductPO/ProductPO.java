package PageObjects.ProductPO;

import DataObjects.ProductPage;
import PageObjects.BasePO.BasePO;
import jdk.swing.interop.SwingInterOpUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ProductPO extends BasePO {

    public ProductPO(WebDriver driver) {
        super(driver);
    }
    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */

    @FindBy(xpath = "//span[text()='3']")
    private WebElement number;

    @FindBy(xpath = "//span[text()='1']")
    private WebElement number1;

    @FindBy(xpath = "//select[@class='product_sort_container']")
    private WebElement dropDown;

    @FindBy(xpath = "//a[@class='shopping_cart_link']")
    private WebElement cartSymbol;

    /**
     * Click on the Add To Cart button
     *
     * @throws InterruptedException Exception
     */
    public  void clickOnAddToCartButton(ProductPage product) throws InterruptedException {
        String addToCart="//button[@id='"+product.getBagPackAddToCart()+"']";
        selenium.waitTillElementIsVisible(By.xpath(addToCart),5);
        selenium.clickOn(By.xpath(addToCart));
        String addToCart1="//button[@id='"+product.getBackLightAddToCart()+"']";
        selenium.waitTillElementIsClickable(By.xpath(addToCart1));
        selenium.clickOn(By.xpath(addToCart1));
        String addToCart2="//button[@id='"+product.getBoltTShirtAddToCart()+"']";
        selenium.waitTillElementIsClickable(By.xpath(addToCart2));
        selenium.clickOn(By.xpath(addToCart2));
    }

    /**
     * check no. of product added into cart is displayed
     * @throws InterruptedException Exception
     */
    public boolean isDisplayed(By by){
       return selenium.isElementPresent(by);
    }

    /**
     * Click on the Add To Cart button
     * @throws InterruptedException Exception
     */
    public void clickOnAddToCartFromIndividualProductLink(ProductPage product) throws InterruptedException {
        String productLink="//div[text()='"+product.getBackPackProductLink()+"']";
        selenium.waitTillElementIsVisible(By.xpath(productLink),5);
        selenium.clickOn(By.xpath(productLink));
        String addToCart="//button[@id='"+product.getBagPackAddToCart()+"']";
        selenium.waitTillElementIsVisible(By.xpath(addToCart),5);
        selenium.clickOn(By.xpath(addToCart));
    }
    /**
     * Click on the Shopping Cart Symbol
     * @throws InterruptedException Exception
     */
    public void clickOnShoppingCartSymbol() throws InterruptedException {
        selenium.waitTillElementIsVisible(cartSymbol);
        selenium.clickOn(cartSymbol);
    }
    /**
     *Select the Value from'Sort Container' Dropdown
     * @throws InterruptedException Exception
     */
    public void selectTheValueFromDropdown(ProductPage product) throws InterruptedException {
        selenium.clickOn(dropDown);
        WebElement dropDownValue = driver.findElement(By.tagName("select"));
        String dropdowns ="//select[@class=\"product_sort_container\"]//option[text()='"+product.getDropDownVlaue()+"']";
      List<String> value= selenium.getAllDropDownValues(dropDownValue);
        if (dropdowns.equals(value)) {
            System.out.println("dropdown value is not selected");
        } else {
            selenium.clickOn(By.xpath(dropdowns));
        }


//      selenium.clickOn(By.xpath(dropdown));
    }

}
