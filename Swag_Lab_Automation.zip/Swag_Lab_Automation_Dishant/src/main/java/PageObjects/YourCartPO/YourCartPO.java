package PageObjects.YourCartPO;

import PageObjects.BasePO.BasePO;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YourCartPO extends BasePO {

    public YourCartPO(WebDriver driver) {
        super(driver);
    }

    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */
    @FindBy(xpath = "//button[text()='Checkout']")
    private WebElement checkoutButton;

    @FindBy(xpath = "(//button[text()='Remove'])[1]")
    private WebElement removeButton;

    @FindBy(xpath = "//button[@name='continue-shopping']")
    private WebElement continueShopping;

    /**
     * Click on the CheckOut button
     * @throws InterruptedException Exception
     */
    public void clickOnCheckoutButton() throws InterruptedException {
        selenium.waitTillElementIsVisible(checkoutButton);
        selenium.clickOn(checkoutButton);
    }
    /**
     * Click on the Remove button
     * @throws InterruptedException Exception
     */

    public void clickOnRemoveButton() throws InterruptedException {
        selenium.waitTillElementIsVisible(removeButton);
        selenium.clickOn(removeButton);
    }

    /**
     * check the element present or not
     * @throws InterruptedException Exception
     */
    public Boolean isProductPresent() {
        return selenium.isElementPresent(removeButton);
    }
    /**
     * Click on the Continue Shopping button
     * @throws InterruptedException Exception
     */
    public void clickOnContinueShoppingButton() throws InterruptedException {
        selenium.waitTillElementIsClickable(continueShopping);
        selenium.clickOn(continueShopping);
    }

}
