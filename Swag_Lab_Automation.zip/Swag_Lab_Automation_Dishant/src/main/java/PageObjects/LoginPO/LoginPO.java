package PageObjects.LoginPO;

import DataObjects.Login;
import PageObjects.BasePO.BasePO;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPO extends BasePO {
    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */

    public LoginPO(WebDriver driver) {
        super(driver);
    }
    @FindBy(xpath = "//input[@placeholder='Username']")
    private WebElement userName;

    @FindBy(xpath = "//input[@placeholder='Password']")
    private WebElement password;

    @FindBy(xpath = "//input[@name='login-button']")
    private WebElement login;

    @FindBy(xpath = "//div[@class='app_logo']")
    private WebElement headerText;

    @FindBy(xpath = "//h3[@data-test='error']")
    private WebElement  warn;
    @FindBy(xpath = "//div[@class='login_logo']")
    private WebElement  Logo;
    @FindBy(xpath = "//h3[@data-test='error']")
    private WebElement  blankWarningMessage;

    /**
     * Enter login credentials and click on the login button
     *
     * @param Username username
     * @param Password password
     * @throws InterruptedException
     */
    public void loginWithValidCredentials(String Username,String Password) throws InterruptedException {
       selenium.waitTillElementIsClickable(userName);
       selenium.enterText(userName,Username,true);
       selenium.clickOn(password);
       selenium.enterText(password,Password,true);
       selenium.clickOn(login);
    }
    /**
     * Enter Invalid login credentials and click on the login button
     *
     * @param logindataa dataobjects
     * @throws InterruptedException
     */
    public void loginWithInvalidCredentials(Login logindataa) throws InterruptedException {
        selenium.waitTillElementIsClickable(userName);
        selenium.enterText(userName,logindataa.getInvalidUserName(),true);
        selenium.clickOn(password);
        selenium.enterText(password,logindataa.getInvalidPassword(),true);
        selenium.clickOn(login);
    }

    /**
     * Get Warning Message after clicking on login button
     */
    public String getWarnMessage(){
        return selenium.getText(warn);

    }

    /**
     * Check the logo is Present or not
     */
    public boolean isLogoDisplayed(){
     return  selenium.isElementPresent(Logo);
    }

    /**
     * Click on the Login button
     *
     * @throws InterruptedException Exception
     */
    public void clickOnLoginButton() throws InterruptedException {
        selenium.clickOn(login);
    }

    /**
     * Get Warning Message after clicking on login button.
     */
    public String getBlankWarnMessage(){
        return selenium.getText(blankWarningMessage);
    }

}
