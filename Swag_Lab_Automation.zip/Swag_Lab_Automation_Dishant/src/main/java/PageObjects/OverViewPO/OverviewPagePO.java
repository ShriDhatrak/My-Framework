package PageObjects.OverViewPO;

import PageObjects.BasePO.BasePO;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OverviewPagePO extends BasePO {

    public OverviewPagePO(WebDriver driver) {
        super(driver);
    }
    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */
    @FindBy(xpath = "//button[@id='finish']")
    private WebElement finishButton;

    @FindBy(id = "cancel")
    private WebElement cancel;

    /**
     * Click on the Finish button
     *
     * @throws InterruptedException Exception
     */
    public  void clickOnFinishButton() throws InterruptedException {
        selenium.pageScrollInView(By.xpath("//div[text()='SauceCard #31337']"));
        selenium.clickOn(finishButton);
    }

    /**
     * Click on the Cancel button
     *
     * @throws InterruptedException Exception
     */
    public  void clickOnCancelButton() throws InterruptedException {
        selenium.pageScrollInView(finishButton);
//        selenium.waitTillElementIsVisible(cancel);
        selenium.clickOn(cancel);
    }
}
