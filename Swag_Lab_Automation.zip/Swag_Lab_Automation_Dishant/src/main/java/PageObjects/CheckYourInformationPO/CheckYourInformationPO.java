package PageObjects.CheckYourInformationPO;

import DataObjects.CheckYourInformation;
import PageObjects.BasePO.BasePO;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckYourInformationPO extends BasePO {

    public CheckYourInformationPO(WebDriver driver) {
        super(driver);
    }
    /*
     * All WebElements are identified by @FindBy annotation
     * @FindBy can accept tagName, partialLinkText, name, linkText, id, css, className, xpath as attributes.
     */

    @FindBy(id = "first-name")
    private WebElement firstName;

    @FindBy(id = "last-name")
    private WebElement lastName;

    @FindBy(id = "postal-code")
    private WebElement postalCode;

    @FindBy(id = "continue")
    private WebElement continueButton;

    @FindBy(id = "cancel")
    private WebElement cancelButton;

    @FindBy(xpath = "//button[text()='Open Menu']")
    private WebElement menu;

    @FindBy(xpath = "//a[text()='Logout']")
    private WebElement logOut;


    /**
     * Enter the Valid Data in Your Information Page
     * @throws InterruptedException Exception
     */
    public void enterValidDataInYourInformationPage(CheckYourInformation check) throws InterruptedException {
        selenium.clickOn(firstName);
        selenium.enterText(firstName,check.getFirstName(),true);
        selenium.click(lastName);
        selenium.enterText(lastName,check.getLastName(),true);
        selenium.click(postalCode);
        selenium.enterText(postalCode,check.getPostalCode(),true);
        selenium.clickOn(continueButton);
    }

    /**
     * Click on Cancel button
     * @throws InterruptedException Exception
     */
    public void clickOnCancelButton() throws InterruptedException {
        selenium.clickOn(cancelButton);

    }

    /**
     * Click on the LogOut button
     * @throws InterruptedException Exception
     */
    public void clickOnLogoutLink() throws InterruptedException {
        selenium.clickOn(menu);
        selenium.waitTillElementIsVisible(logOut);
        selenium.clickOn(logOut);
    }

}
