package DataFactory;

import DataObjects.Login;
import PageObjects.LoginPO.LoginPO;

public class loginData {

    public  Login getLoginData(){
        Login loginData = new Login();
        loginData.setInvalidUserName("locked_out_user");
        loginData.setInvalidPassword("abc123");
        return loginData;
    }
}
