package DataFactory;

import DataObjects.ProductPage;

public class ProductPageData {
    public ProductPage getProductPageData() {
        ProductPage product = new ProductPage();
        product.setBagPackAddToCart("add-to-cart-sauce-labs-backpack");
        product.setBackLightAddToCart("add-to-cart-sauce-labs-bike-light");
        product.setBoltTShirtAddToCart("add-to-cart-sauce-labs-bolt-t-shirt");
        product.setBackPackProductLink("Sauce Labs Backpack");
        product.setBackLightProductLink("Sauce Labs Bike Light");
        product.setBoltTShirtLink("Sauce Labs Bolt T-Shirt");
        product.setDropDownVlaue("Price (low to high)");
        return product;
    }
}
