package DataFactory;

import DataObjects.CheckYourInformation;

public class CheckYourInformationData {
    public CheckYourInformation getCheckYourInformationData(){
        CheckYourInformation checkData = new CheckYourInformation();
        checkData.setFirstName("vishal");
        checkData.setLastName("rathiod");
        checkData.setPostalCode("431705");
        return checkData;
    }
}
