package DataObjects;

public class ProductPage {
    private String bagPackAddToCart;
    private String backLightAddToCart;
    private String boltTShirtAddToCart;
    private String backPackProductLink;
    private String backLightProductLink;
    private String boltTShirtLink;
    private String dropDownVlaue;

    public String getDropDownVlaue() {
        return dropDownVlaue;
    }

    public void setDropDownVlaue(String dropDownVlaue) {
        this.dropDownVlaue = dropDownVlaue;
    }



    public String getBackPackProductLink() {
        return backPackProductLink;
    }

    public void setBackPackProductLink(String backPackProductLink) {
        this.backPackProductLink = backPackProductLink;
    }

    public String getBackLightProductLink() {
        return backLightProductLink;
    }

    public void setBackLightProductLink(String backLightProductLink) {
        this.backLightProductLink = backLightProductLink;
    }

    public String getBoltTShirtLink() {
        return boltTShirtLink;
    }

    public void setBoltTShirtLink(String boltTShirtLink) {
        this.boltTShirtLink = boltTShirtLink;
    }



    public String getBoltTShirtAddToCart() {
        return boltTShirtAddToCart;
    }

    public void setBoltTShirtAddToCart(String boltTShirtAddToCart) {
        this.boltTShirtAddToCart = boltTShirtAddToCart;
    }



    public String getBagPackAddToCart() {
        return bagPackAddToCart;
    }

    public void setBagPackAddToCart(String bagPackAddToCart) {
        this.bagPackAddToCart = bagPackAddToCart;
    }

    public String getBackLightAddToCart() {
        return backLightAddToCart;
    }

    public void setBackLightAddToCart(String backLightAddToCart) {
        this.backLightAddToCart = backLightAddToCart;
    }




}
